export default {
  LOGO: require('../../assets/logo.png'),
  PASSWORD: require('../../assets/pass.png'),
  USERNAME: require('../../assets/username.png'),
  EMAIL: require('../../assets/email.png'),
  SETTING: require('../../assets/settings.png'),
  LOGOUT: require('../../assets/logout.png'),
};
