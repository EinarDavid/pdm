# React, React Native, React Navigation, Firebase, Firestore and Adobe XD
> This application uses: React Native and Firebase. Login Screen Page 2020.

>GooWil App 

![](assets/pdm1.png#) ![](assets/pdm2.png#)


![](assets/pdm3.png#) ![](assets/pdm4.png#)

## Installation

FrontEnd:

```sh
cd reana
npm install
```

## Development setup

To run the application, it is necessary to have running the frontend app

```sh
cd reana
npx react-native run-android
```

## Release History

* 0.0.1
    * Work in progress

## Meta

Dheeyi William – [@YourTwitter](https://twitter.com/dheeyi) – dheeyi@gmail.com

See ``MIT LICENSE`` for more information.

[https://github.com/dheeyi/](https://github.com/dheeyi/)

